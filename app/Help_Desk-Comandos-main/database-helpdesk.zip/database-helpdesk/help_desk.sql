create database help_desk;
use helpdesk;

DROP TABLE IF EXISTS historico;
DROP TABLE IF EXISTS chamados;
DROP TABLE IF EXISTS colaboradores;
DROP TABLE IF EXISTS cadastro;

CREATE TABLE cadastro (
    id_cliente INT(6) PRIMARY KEY NOT NULL,
    nome VARCHAR(15) NOT NULL,
    celular VARCHAR(15) NOT NULL,
    CPF VARCHAR(11) NOT NULL,
    email VARCHAR(30) NOT NULL,
    senha VARCHAR(20) NOT NULL,
    data_nascimento DATE NOT NULL,
    cidade VARCHAR(15) NOT NULL,
    estado VARCHAR(15) NOT NULL
);

CREATE TABLE colaboradores(
    id_colaboradores INT(6) PRIMARY KEY NOT NULL,
    nome VARCHAR(15) NOT NULL,
    celular VARCHAR(15) NOT NULL,
    CPF VARCHAR(11) NOT NULL,
    email VARCHAR(30) NOT NULL,
    senha VARCHAR(20)NOT NULL,
    data_nascimento DATE NOT NULL,
    cidade VARCHAR(15) NOT NULL,
    estado VARCHAR(15) NOT NULL,
    especialidade VARCHAR(70) NOT NULL,
    status VARCHAR(20) NOT NULL
);

CREATE TABLE chamados (
    id_chamados INT PRIMARY KEY NOT NULL,
    id_cliente INT NOT NULL,
    id_colaboradores INT NOT NULL,
    descricao VARCHAR(300),
    data_abertura DATE NOT NULL,
    data_fechamento DATE,
    status VARCHAR(20) NOT NULL,
    valor decimal(10,2) NOT NULL,

    FOREIGN KEY (id_cliente) REFERENCES cadastro(id_cliente),
    FOREIGN KEY (id_colaboradores) REFERENCES colaboradores(id_colaboradores)
);

CREATE TABLE historico (
    id_historico INT PRIMARY KEY NOT NULL,
    id_chamados INT NOT NULL,
    data_evento DATE NOT NULL,
    descricao VARCHAR(300),

    FOREIGN KEY (id_chamados) REFERENCES chamados(id_chamados)
);
